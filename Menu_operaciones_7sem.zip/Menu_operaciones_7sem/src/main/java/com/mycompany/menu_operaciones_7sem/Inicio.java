/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.menu_operaciones_7sem;
import java.util.*;
/**
 *
 * @author acerpc
 */
public class Inicio {
        public static void main(String[] args) {
            Scanner leer=new Scanner(System.in);
            int opc=0;
           
            while (true) {    
            System.out.println("");
            System.out.println("Elige una opcion");
            System.out.println("1. Expresión aritmética");
            System.out.println("2. Expresión lógica");
            System.out.println("3. Expresión lógica V2");
            System.out.println("4. Salir");
            opc=leer.nextInt();
                switch(opc){
                case 1:
                    //System.out.println("Por el momento no esta disponible opc 1");
                    System.out.println(" ");
                    System.out.println("_______________________________________________________________________________________");
                    new Aritmetica();
                    break;
                case 2:
                   // System.out.println("Por el momento no esta disponible opc 2");
                    System.out.println(" ");
                    System.out.println("_______________________________________________________________________________________");
                    new Tablas_Verdad();
                    break;
                case 3:
                    System.out.println(" ");
                    System.out.println("_______________________________________________________________________________________");
                    new Cont_letras_numeros();
                    break;
                case 4:
                    System.exit(0);
                    break;
                 default:
                     System.out.println("inválida, verifica las opciones!!");
                    break;
            }
                
            }            
            
        }
}
