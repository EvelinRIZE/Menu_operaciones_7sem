
package com.mycompany.menu_operaciones_7sem;
import java.io.*;
import java.util.*;

public class Cont_letras_numeros {
    public Cont_letras_numeros() {
       
        Scanner leer=new Scanner (System.in);
        String texto;
        int num=0,letra=0,longitud=0,simb=0, largos=0;
        System.out.println("Introduzca la cadena: ");
        texto=leer.nextLine(); //Guarda la cadena colocada
       
     String [] espacios = texto.split(" ");

     for( String elemento: espacios ){ //For que recorre el array separada y regresa cada elemento en un String llamado elemento
         // En este apartado donde se obtiene la longitud de la cadena que esta ingresando el usuario. 
         longitud++;
          
         if( elemento.matches("[+-]?\\d*(\\.\\d+)?") ){ //comparamos si elemento tiene un simbolo negativo, tiene digitos, (puede tener punto decimal y mas digitos)
                
                System.out.println("Es un numero: "+ "["+elemento+"]");
                num++;
            }else{
                if(elemento.length() > 1 ){ //Visto que no es un numero si la cantidad de caracteres es mayor a 1 significa que es un String
                    System.out.println("Es mas de un caracter: "+"["+elemento+"]");
                    largos++;
                }else{
                    // si no tuvo mas de 1 caracter
                   if( elemento.length() > 1 || elemento.matches("[abcdefghijklmnñopqrstuvxyz]")){
                                              
                      System.out.println("Es una letra: "+"["+elemento+"]");
                    letra++;
                    }else{
                        System.out.println("Es un simbolo: "+"["+elemento+"]");
                       simb++;
                   }
                    }
            }
         
     }
        System.out.println("Cantidad de caracteres ingresados son: "+longitud); 
        System.out.println("De letras son: "+letra);
        System.out.println("De numeros son: "+num);
        System.out.println("Cantidad de Símbolos : "+simb);
    }
}

