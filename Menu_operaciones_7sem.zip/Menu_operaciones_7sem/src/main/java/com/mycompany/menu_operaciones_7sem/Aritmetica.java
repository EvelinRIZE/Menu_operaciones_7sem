/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.menu_operaciones_7sem;

import java.util.*;

/**
 *
 * @author acerpc
 */
public class Aritmetica {
    
     public Aritmetica(){
         
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingresa la expresión");
        String expres=leer.nextLine();
     // System.out.println("Ingresa la expresión");
        String expr=depurar(expres);
                
        Verifica analizador = new Verifica();              
        // En este apartado se estan declaron las pilas que vamos a ocupar
        String[] arrayInfix=expr.split(" ");        
        Stack < String > entrada=new Stack < String > ();//Esta representa la pila de inicio
        Stack < String > temporal = new Stack < String > (); //Esta es la pila temporar, es decir, donde va a ir cambiando.
        Stack < String > salida= new Stack < String > (); //Esta es la pila donde va a mostrar el resultado fina.
       
        //Añadir la array a la Pila de entrada 
        for (int i = arrayInfix.length-1; i >= 0; i--) {
            entrada.push(arrayInfix[i]);
        }
        
        try
        {
           //Codigo del algoritmo Infijo a Postfijo
            while(!entrada.isEmpty())
            {
                switch (pref(entrada.peek()))
                {
                    case 1:
                        temporal.push(entrada.pop());
                        break;
                    case 3:
                    case 4:
                        while(pref(temporal.peek()) >= pref(entrada.peek()))
                        {
                            salida.push(temporal.pop());
                        }
                        temporal.push(entrada.pop());
                        break;
                    case 2:
                        while(!temporal.peek().equals("("))
                        {
                            salida.push(temporal.pop());
                        }
                        temporal.pop();
                        entrada.pop();
                        break;
                    default:
                        salida.push(entrada.pop());
                }
            }
            
            //Eliminacion de `impurezas´ en la expresiones algebraicas
        String infix=expr.replace(" ", "");
        String postfix=salida.toString().replaceAll("[\\]\\[,]", "");
            
           //Mostrar resultados:
           /* System.out.println("Expresion Infija: " + infix);
            System.out.println("Expresion Postfija: " + postfix);*/
            
            
        } catch(Exception ex)
        {
            System.out.println("___________");
           // System.err.println(ex);
        }
        
    try {
            System.out.println("El Resultado de la expresión ingresada es: "+analizador.evaluar(expres));
             System.out.println("___________");
        }catch(Excepciones exc) {
           // System.out.println(exc);
        }    
    }
    
    private static String depurar(String s){
       s = s.replaceAll("\\s+", ""); //Elimina espacios en blanco, es decir, sin importar la cantidad de espacios que tenga
				// la cadadena no va a marcar error ya que aqui va eliminando los espacios inecesarios 
        String simbols = "+-*/()"; // si es que tiene alguuno de esos sombolos
        String str= "";
         //Deja espacios entre operadores, pero los necesarios para así realizar bien el desarrollo
        for (int i = 0; i < s.length(); i++) {
            if(simbols.contains("" + s.charAt(i))){
                str+=" "+ s.charAt(i)+ " ";
            }else str+=s.charAt(i);
        }
        return str.replaceAll("\\s+", " ").trim();

    }
    private static int pref(String op){
        int prf=99;
        if(op.equals("^")) prf=5;
        if(op.equals("*") || op.equals("/")) prf=4;
        if(op.equals("+") || op.equals("-")) prf=3;
        if(op.equals(")")) prf=2;
        if(op.equals("(")) prf=1;
        return prf; 
       
    }
                
}