/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.menu_operaciones_7sem;

/**
 *
 * @author acerpc
 */
public class Tablas_Verdad {
    public Tablas_Verdad(){
    System.out.println("La expresión a evaluar es: [(p->q)^p]->q");
                   
                    String p[]={"v","v","f","f"};
                    String q[]={"v","f","v","f"}; 
                    String res[]=new String[4];
                    //es donde inicia el desarrollo, es decir, va comparando que valor se obtiene así ver si es falso o verdadero
                    for (int i = 0; i < res.length; i++) {
                        if (p[i].equals("V")&&q[i].equals("F")) {
                            res[i]="F";
                        }else{
                            res[i]="V";
                        }
                       // System.out.println("Verificación 1 XD: "+a1[i]);
                    }
                    
                    for (int i = 0; i < res.length; i++) {
                    if (res[i].equals("V")&&p[i].equals("V")) {
                            res[i]="V";
                        }else{
                            res[i]="F";
                        }
                       // System.out.println("Verificacion 2 XD: "+a1[i]);
                    }
			
                    for (int i = 0; i < res.length; i++) {
                    if (res[i].equals("V")&&p[i].equals("F")) {
                            res[i]="F";
                        }else{
                            res[i]="V";
                        }
			// Aqui es donde se imprime el resultado obtenido
                        System.out.print("[ "+res[i]+"] ");
                    }
        }
    }
